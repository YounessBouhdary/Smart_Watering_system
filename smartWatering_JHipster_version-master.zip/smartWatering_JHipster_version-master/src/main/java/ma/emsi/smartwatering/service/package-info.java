/**
 * Service layer beans.
 */
package ma.emsi.smartwatering.service;
