/**
 * Data Transfer Objects.
 */
package ma.emsi.smartwatering.service.dto;
