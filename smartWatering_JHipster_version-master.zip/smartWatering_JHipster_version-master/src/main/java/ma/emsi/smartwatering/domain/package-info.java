/**
 * JPA domain objects.
 */
package ma.emsi.smartwatering.domain;
