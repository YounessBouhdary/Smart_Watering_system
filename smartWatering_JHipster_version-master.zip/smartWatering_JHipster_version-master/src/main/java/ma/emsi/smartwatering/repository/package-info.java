/**
 * Spring Data JPA repositories.
 */
package ma.emsi.smartwatering.repository;
