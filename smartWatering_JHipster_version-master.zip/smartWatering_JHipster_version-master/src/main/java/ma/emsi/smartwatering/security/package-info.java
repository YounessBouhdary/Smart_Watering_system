/**
 * Spring Security configuration.
 */
package ma.emsi.smartwatering.security;
