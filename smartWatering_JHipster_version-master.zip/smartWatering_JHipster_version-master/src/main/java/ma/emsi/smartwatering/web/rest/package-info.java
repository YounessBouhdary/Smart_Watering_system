/**
 * Spring MVC REST controllers.
 */
package ma.emsi.smartwatering.web.rest;
