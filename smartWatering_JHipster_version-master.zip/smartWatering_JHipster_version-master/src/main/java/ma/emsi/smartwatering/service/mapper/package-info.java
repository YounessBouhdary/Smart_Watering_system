/**
 * MapStruct mappers for mapping domain objects and Data Transfer Objects.
 */
package ma.emsi.smartwatering.service.mapper;
