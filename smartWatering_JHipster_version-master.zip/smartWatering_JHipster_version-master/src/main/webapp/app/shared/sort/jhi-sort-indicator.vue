<template>
  <font-awesome-icon :icon="currentOrder === fieldName ? (reverse ? 'sort-down' : 'sort-up') : 'sort'"> </font-awesome-icon>
</template>

<script lang="ts" src="./jhi-sort-indicator.component.ts"></script>
