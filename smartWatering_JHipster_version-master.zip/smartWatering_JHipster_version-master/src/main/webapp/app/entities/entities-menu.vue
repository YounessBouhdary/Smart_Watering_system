<template>
  <div>
    <b-dropdown-item to="/extra-user">
      <font-awesome-icon icon="asterisk" />
      <span>Extra User</span>
    </b-dropdown-item>
    <b-dropdown-item to="/notification">
      <font-awesome-icon icon="asterisk" />
      <span>Notification</span>
    </b-dropdown-item>
    <b-dropdown-item to="/espace-vert">
      <font-awesome-icon icon="asterisk" />
      <span>Espace Vert</span>
    </b-dropdown-item>
    <b-dropdown-item to="/zone">
      <font-awesome-icon icon="asterisk" />
      <span>Zone</span>
    </b-dropdown-item>
    <b-dropdown-item to="/grandeur">
      <font-awesome-icon icon="asterisk" />
      <span>Grandeur</span>
    </b-dropdown-item>
    <b-dropdown-item to="/type-sol">
      <font-awesome-icon icon="asterisk" />
      <span>Type Sol</span>
    </b-dropdown-item>
    <b-dropdown-item to="/plante">
      <font-awesome-icon icon="asterisk" />
      <span>Plante</span>
    </b-dropdown-item>
    <b-dropdown-item to="/plantage">
      <font-awesome-icon icon="asterisk" />
      <span>Plantage</span>
    </b-dropdown-item>
    <b-dropdown-item to="/type-plante">
      <font-awesome-icon icon="asterisk" />
      <span>Type Plante</span>
    </b-dropdown-item>
    <b-dropdown-item to="/installation">
      <font-awesome-icon icon="asterisk" />
      <span>Installation</span>
    </b-dropdown-item>
    <b-dropdown-item to="/boitier">
      <font-awesome-icon icon="asterisk" />
      <span>Boitier</span>
    </b-dropdown-item>
    <b-dropdown-item to="/connecte">
      <font-awesome-icon icon="asterisk" />
      <span>Connecte</span>
    </b-dropdown-item>
    <b-dropdown-item to="/capteur">
      <font-awesome-icon icon="asterisk" />
      <span>Capteur</span>
    </b-dropdown-item>
    <b-dropdown-item to="/arrosage">
      <font-awesome-icon icon="asterisk" />
      <span>Arrosage</span>
    </b-dropdown-item>
    <!-- jhipster-needle-add-entity-to-menu - JHipster will add entities to the menu here -->
  </div>
</template>

<script lang="ts" src="./entities-menu.component.ts"></script>
