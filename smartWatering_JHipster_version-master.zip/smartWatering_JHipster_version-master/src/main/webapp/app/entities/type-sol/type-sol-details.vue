<template>
  <div class="row justify-content-center">
    <div class="col-8">
      <div v-if="typeSol">
        <h2 class="jh-entity-heading" data-cy="typeSolDetailsHeading"><span>TypeSol</span> {{ typeSol.id }}</h2>
        <dl class="row jh-entity-details">
          <dt>
            <span>Lebelle</span>
          </dt>
          <dd>
            <span>{{ typeSol.lebelle }}</span>
          </dd>
          <dt>
            <span>Description</span>
          </dt>
          <dd>
            <span>{{ typeSol.description }}</span>
          </dd>
        </dl>
        <button type="submit" v-on:click.prevent="previousState()" class="btn btn-info" data-cy="entityDetailsBackButton">
          <font-awesome-icon icon="arrow-left"></font-awesome-icon>&nbsp;<span> Back</span>
        </button>
        <router-link v-if="typeSol.id" :to="{ name: 'TypeSolEdit', params: { typeSolId: typeSol.id } }" custom v-slot="{ navigate }">
          <button @click="navigate" class="btn btn-primary">
            <font-awesome-icon icon="pencil-alt"></font-awesome-icon>&nbsp;<span> Edit</span>
          </button>
        </router-link>
      </div>
    </div>
  </div>
</template>

<script lang="ts" src="./type-sol-details.component.ts"></script>
